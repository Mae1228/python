Python3的安装
=============

## 知识点

* Python3的下载与安装

## 下载网址

https://www.python.org/downloads/

**注意32位版本和64位版本，不要选错！**

## 本地安装

## 实战演习

### VSCode设置

1. Ctrl + Shift + P
2. Python: Select Interpreter

### helo.py

~~~python
def helo():
    return "Helo Python World!"

print(helo())
~~~

## 课程文件

https://github.com/komavideo/LearnPython3

## 小马视频频道

http://komavideo.com
