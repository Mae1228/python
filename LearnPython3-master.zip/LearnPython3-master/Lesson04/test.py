# 删除余白
msg = " Curry is MVP. "
print("|" + msg + "|")
print("|" + msg.rstrip() + "|")
print("|" + msg.lstrip() + "|")
print("|" + msg.strip() + "|")