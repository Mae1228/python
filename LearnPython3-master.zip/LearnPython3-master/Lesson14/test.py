point = 5

# if
# if point > 30:
#     print("MVP球星")

# if-else
# if point > 20:
#     print("绝对球星")
# else:
#     print("未来球星")

# if-elif-else
# if point > 30:
#     print("MVP球星")
# elif point >= 20:
#     print("绝对球星")
# else:
#     print("未来球星")

# if-elif-elif-else
if point > 30:
    print("MVP球星")
elif point >= 20:
    print("绝对球星")
elif point >= 10:
    print("未来球星")
else:
    print("普通球员")