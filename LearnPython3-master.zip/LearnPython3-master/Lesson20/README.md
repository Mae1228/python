while高级
==========

## 知识点

* while循环数组(列表)

## 实战演习

~~~python
# 数组
mylist = ["curry", "harden", "lebron", "durant", "kobe"]
print(mylist)

# 循环数组
while mylist:
    player = mylist.pop()
    print(player)

# 同等的for写法
# for player in mylist:
#     print(player)
~~~

## 课程文件

https://github.com/komavideo/LearnPython3

## 小马视频频道

http://komavideo.com
