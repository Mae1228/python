# 数组
mylist = ["curry", "harden", "lebron", "durant", "kobe"]
print(mylist)

# 循环数组
# while mylist:
#     player = mylist.pop()
#     print(player)

# 同等的for写法
for player in mylist:
    print(player)