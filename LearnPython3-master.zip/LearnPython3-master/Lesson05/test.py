# 数值字符串转换
age = 25
msg = "我今年" + str(age) + "岁"
print(msg)
