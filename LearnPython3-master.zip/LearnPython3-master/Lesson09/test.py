mylist = ["curry", "harden", "lebron", "durant", "kobe"]

# 数组循环
# print("Start.")
# for name in mylist:
#     print("\t", name) # 缩进代码
# print("End.")

# 循环索引
for i, item in enumerate(mylist):
    print(i, item)

