# 排序函数
lang_list = ["Python", "Javascript", "RoR", "Kotlin", "Java"]
print(lang_list)
print(sorted(lang_list))
print(sorted(lang_list, reverse=True))
