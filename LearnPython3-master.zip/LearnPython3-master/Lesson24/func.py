def add(x, y):
    return x + y

def minus(x, y):
    return x - y