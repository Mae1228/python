定义函数
========

## 知识点

* 定义函数
* 声明参数
* 参数默认值

## 实战演习

~~~python
# 定义函数
def helo1():
    print("helo world.")

helo1()

# 声明参数
def helo2(name):
    print("helo", name)

helo2("koma")

# 参数默认值
def helo3(name="koma"):
    print("hi", name)

helo3()
helo3("mike")
~~~

## 课程文件

https://github.com/komavideo/LearnPython3

## 小马视频频道

http://komavideo.com
