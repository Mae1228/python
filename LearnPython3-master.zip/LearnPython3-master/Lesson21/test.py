# 定义函数
def helo1():
    print("helo python world!")
# helo1()

# 声明参数
def helo2(name):
    print("helo", name)
# helo2("xiaoma")
helo2()

def add(x, y):
    print(x+y)
# add(10, 13)

# 参数默认值
def helo3(name="koma"):
    print("hi", name)

# helo3("xiaoma")
# helo3("jerry")
