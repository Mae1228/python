mylist = ["curry", "harden", "lebron", "durant", "kobe"]

# 指名删除
print(mylist)
mylist.remove("lebron")
print(mylist)