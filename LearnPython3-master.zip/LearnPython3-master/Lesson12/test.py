tuple_sample = (1, 2, 3, 5, 8, 13)

print(tuple_sample)
# print(tuple_sample[0])
# print(tuple_sample[1])
# print(tuple_sample[2])

# 循环元组
# for val in tuple_sample:
#     print(val)

# 元组不变值
# tuple_sample[0] = 10

# 元组重新设置
tuple_sample = ("a", "b", "c")
print(tuple_sample)
for val in tuple_sample:
    print(val)

tuple_sample[1] = "i love u."
