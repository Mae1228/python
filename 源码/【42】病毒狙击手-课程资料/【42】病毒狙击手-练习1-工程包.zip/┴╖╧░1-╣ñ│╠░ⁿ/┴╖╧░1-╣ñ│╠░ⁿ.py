'''练习1-工程包'''

filelist = ['file.txt', 'fille.txt']

